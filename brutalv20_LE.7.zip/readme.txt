------------------------------
Brutal Doom v20 Legacy Edition
------------------------------

This is a standalone unofficial bugfix release of Brutal Doom 20 and contains the following:
- Original unmodified Brutal Doom V20b with the BLOOD.txt errors fixed.
- Brutal Doom Basic HUD.
- Last My Brutal Doom v20c Unofficial Patch which contains a lot of bugfixes (see brutalv20c_UP.txt).
- ZDoom LE 2.8.3a (GL 1.8.4c), a fork of ZDoom 2.8.1 with a lot of later official bugfixes and a GL renderer requiring only OpenGL 1.2. Runs on win98 and later.
- ZDoom Launcher (ZDL) 3.1a.

Use ZDL to load brutalv20.pk3 and brutalv20c_UP.pk3 (and the appropiate smivhud and any other wads you want to play).
Or just play BD v21. :)

Of course Brutal Doom is made and copyrighted by Sargeant Mark IV.

ZDoom and GZDoom Copyright © 1993-1996 id Software, 1998-2016 Randi Heit, 2002-2018 Christoph Oelckers, et al.
LE version maintained by drfrag from zdoom.org, includes patches by hail-to-the-ryzen.
The ZDoom LE source code can be downloaded from https://github.com/drfrag666/gzdoom.

ZDoom Launcher (C) Ryan "BioHazard" Turner / ZDL Software Foundation

Have fun! Original Brutal Doom still rulez.
